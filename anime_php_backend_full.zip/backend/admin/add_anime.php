<?php
session_start();
require_once __DIR__ . '/../db_connect.php';

if (empty($_SESSION['is_admin'])) {
    http_response_code(403);
    echo 'Forbidden';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo 'Method not allowed';
    exit;
}

$title = trim($_POST['title'] ?? '');
$desc = trim($_POST['description'] ?? '');
$image_url = trim($_POST['image_url'] ?? '');
$genre = trim($_POST['genre'] ?? '');
$release_year = (int)($_POST['release_year'] ?? 0);
$status = trim($_POST['status'] ?? '');

if (!$title) {
    echo 'Title required.';
    exit;
}

$stmt = $pdo->prepare('INSERT INTO anime_list (title, description, image_url, genre, release_year, status) VALUES (?, ?, ?, ?, ?, ?)');
$stmt->execute([$title, $desc, $image_url, $genre, $release_year ?: null, $status]);

header('Location: /backend/admin/');
exit;

<?php
session_start();
require_once __DIR__ . '/../db_connect.php';

// For demo: hard-coded admin (change in production!)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo 'Method not allowed';
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

$ADMIN_USER = 'admin';
$ADMIN_PASS = 'adminpass'; // change immediately

if ($username === $ADMIN_USER && $password === $ADMIN_PASS) {
    $_SESSION['is_admin'] = true;
    header('Location: /backend/admin/');
    exit;
}

echo 'Invalid admin credentials.';

<?php
session_start();
require_once __DIR__ . '/../db_connect.php';

if (empty($_SESSION['is_admin'])) {
    http_response_code(403);
    echo 'Forbidden';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo 'Method not allowed';
    exit;
}

$id = (int)($_POST['id'] ?? 0);
if (!$id) {
    echo 'Invalid id';
    exit;
}

$stmt = $pdo->prepare('DELETE FROM anime_list WHERE id = ? LIMIT 1');
$stmt->execute([$id]);

header('Location: /backend/admin/');
exit;

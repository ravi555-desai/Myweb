<?php
require_once __DIR__ . '/db_connect.php';

// Optional: accept ?limit= & ?offset=
function fetch_anime($limit = 20, $offset = 0) {
    global $pdo;
    $stmt = $pdo->prepare('SELECT id, title, description, image_url, genre, release_year, status FROM anime_list ORDER BY id DESC LIMIT ? OFFSET ?');
    $stmt->bindValue(1, (int)$limit, PDO::PARAM_INT);
    $stmt->bindValue(2, (int)$offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

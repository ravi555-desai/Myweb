<?php
session_start();
require_once __DIR__ . '/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo 'Method not allowed';
    exit;
}

$identifier = trim($_POST['identifier'] ?? ''); // email or username
$password = $_POST['password'] ?? '';

if (!$identifier || !$password) {
    echo 'Fill all fields.';
    exit;
}

// Fetch user by email OR username
$stmt = $pdo->prepare('SELECT id, username, password FROM users WHERE email = ? OR username = ? LIMIT 1');
$stmt->execute([$identifier, $identifier]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    echo 'Invalid credentials.';
    exit;
}

// Set session
$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];

header('Location: /public/index.php');
exit;

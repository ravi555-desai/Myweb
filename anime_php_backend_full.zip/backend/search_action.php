<?php
require_once __DIR__ . '/db_connect.php';

$q = trim($_GET['q'] ?? '');
if ($q === '') {
    echo json_encode([]);
    exit;
}

// Use wildcard search safely
$term = "%" . str_replace('%', '\%', $q) . "%";
$stmt = $pdo->prepare('SELECT id, title, description, image_url, genre, release_year, status FROM anime_list WHERE title LIKE ? OR genre LIKE ? ORDER BY id DESC LIMIT 50');
$stmt->execute([$term, $term]);
$results = $stmt->fetchAll();

header('Content-Type: application/json; charset=utf-8');
echo json_encode($results);

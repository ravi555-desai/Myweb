<!doctype html>
<html>
<head><meta charset="utf-8"><title>Signup</title></head>
<body>
  <h2>Signup</h2>
  <form method="POST" action="/backend/auth_signup.php">
    <input type="text" name="username" placeholder="Username" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button type="submit">Signup</button>
  </form>
  <p><a href="login.php">Login</a></p>
</body>
</html>

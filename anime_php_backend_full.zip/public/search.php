<?php
$q = trim($_GET['q'] ?? '');
if ($q === '') {
  echo 'No query';
  exit;
}

$resultsJson = file_get_contents('http://localhost/backend/search_action.php?q=' . urlencode($q));
$results = json_decode($resultsJson, true);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Search: <?=htmlspecialchars($q)?></title></head>
<body>
  <h1>Search results for <?=htmlspecialchars($q)?></h1>
  <?php if (empty($results)): ?>
    <p>No results</p>
  <?php else: ?>
    <?php foreach ($results as $r): ?>
      <div>
        <h3><?=htmlspecialchars($r['title'])?></h3>
        <p><?=htmlspecialchars($r['description'])?></p>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</body>
</html>

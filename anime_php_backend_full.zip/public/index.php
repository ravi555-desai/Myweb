<?php
require_once __DIR__ . '/../backend/fetch_anime.php';
$animes = fetch_anime(50, 0);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Anime List</title>
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
  <h1>Anime List</h1>
  <form action="search.php" method="get">
    <input type="text" name="q" placeholder="Search anime...">
    <button type="submit">Search</button>
  </form>

  <div id="list">
    <?php foreach ($animes as $a): ?>
      <div class="anime-card">
        <img src="<?=htmlspecialchars($a['image_url'])?>" alt="" width="120">
        <h3><?=htmlspecialchars($a['title'])?></h3>
        <p><?=htmlspecialchars($a['description'])?></p>
      </div>
    <?php endforeach; ?>
  </div>

  <p><a href="login.php">Login</a> | <a href="signup.php">Signup</a></p>
</body>
</html>

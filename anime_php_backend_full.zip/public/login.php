<!doctype html>
<html>
<head><meta charset="utf-8"><title>Login</title></head>
<body>
  <h2>Login</h2>
  <form method="POST" action="/backend/auth_login.php">
    <input type="text" name="identifier" placeholder="Email or Username" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button type="submit">Login</button>
  </form>
  <p><a href="signup.php">Signup</a></p>
</body>
</html>

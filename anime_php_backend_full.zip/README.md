# Anime PHP Backend - Setup

## Files included
- backend/: PHP backend files (db connection, auth, search, admin)
- public/: Public-facing pages (index, login, signup, search)
- sql/: Database schema + sample data
- assets/: CSS/images folder

## Setup steps
1. Copy the project folder to your web server root (e.g., /var/www/html/anime_php_backend_full).
2. Create a MySQL user and run `sql/anime_schema.sql` to create tables and sample data.
3. Update database credentials in `backend/db_connect.php`.
4. Ensure PHP (>=7.4) and PDO MySQL extension are installed.
5. For admin: edit `backend/admin/admin_login.php` to set secure credentials or create an admins table.
6. Access the site at `http://yourserver/public/index.php`.

## Security notes
- Change default admin credentials immediately.
- Use HTTPS in production.
- Sanitize and validate any file uploads (not included).

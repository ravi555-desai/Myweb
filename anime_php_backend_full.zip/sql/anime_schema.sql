-- Create database and user (run as root or with enough privileges)
CREATE DATABASE IF NOT EXISTS anime_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE anime_db;

-- users table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- anime table
CREATE TABLE IF NOT EXISTS anime_list (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  image_url VARCHAR(500),
  genre VARCHAR(150),
  release_year INT,
  status VARCHAR(50),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- sample data
INSERT INTO anime_list (title, description, image_url, genre, release_year, status) VALUES
('Naruto', 'A young ninja...', 'https://example.com/naruto.jpg', 'Action', 2002, 'Completed'),
('One Piece', 'Pirate adventure...', 'https://example.com/onepiece.jpg', 'Adventure', 1999, 'Ongoing');
